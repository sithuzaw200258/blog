<?php require_once "template/header.php";?>
    <div class="row">
        <div class="col-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb bg-white mb-4">
                    <li class="breadcrumb-item"><a href="dashboard.html"><i class="feather-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="item-lists.html">Items</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Add Item</li>
                </ol>
            </nav>
        </div>
    </div>


<?php require_once "template/footer.php";?>