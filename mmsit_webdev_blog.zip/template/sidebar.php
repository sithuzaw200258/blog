
<div class="col-12 col-lg-3 col-xl-2 vh-100 sidebar">
    <div class="d-flex justify-content-between align-items-center py-2 mt-3 navbar-brand">
        <div class="d-flex align-items-center">
                    <span class="bg-primary rounded p-2 d-flex justify-content-center align-items-center mr-2">
                        <i class="feather-shopping-bag text-white"></i>
                    </span>
            <span class="text-primary text-uppercase font-weight-bolder h4 mb-0">My Shop</span>
        </div>

        <button class="hide-sidebar-btn btn btn-light btn-sm d-block d-lg-none">
            <i class="feather-x" style="font-size: 2em"></i>
        </button>
    </div>

    <div class="nav-menu">
        <ul>

            <!--Dashboard-->
            <li class="menu-item">
                <a href="dashboard.html" class="menu-item-link active">
                   <span>
                       <i class="feather-home"></i>
                        Dashboard
                   </span>

                </a>
            </li>
            <li class="menu-spacer"></li>

            <!-- Real Manage Item -->
            <li class="menu-title">
                Manage Item
            </li>
            <li class="menu-item">
                <a href="item-add.html" class="menu-item-link">
                   <span>
                       <i class="feather-plus-circle"></i>
                        Add Item
                   </span>

                </a>
            </li>

            <li class="menu-item">
                <span>
                   <a href="item-lists.html" class="menu-item-link">
                       <span>
                           <i class="feather-menu"></i>
                           Item Lists
                       </span>

                       <span class="badge badge-pill bg-white shadow-sm text-primary p-1">15</span>

                   </a>
                </span>
            </li>

            <li class="menu-spacer"></li>

            <li class="menu-item">
                <span>
                   <a href="logout.php" class="menu-item-link btn btn-primary text-white">
                       <span>
                           <i class="feather-log-out"></i>
                           Logout
                       </span>
                   </a>
                </span>
            </li>


        </ul>
    </div>

</div>
