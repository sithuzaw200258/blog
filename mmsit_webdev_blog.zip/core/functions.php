<?php

//=============  Common Functions  =============

function alert($data,$color){
    return "<p class='alert alert-$color'>$data</p>";
}

function runQuery($sql){
    if (mysqli_query(conn(),$sql)){
        return true;
    }else{
        //alert('Database Error','danger');
        die("Query Fail ".mysqli_error());
    }
}

function redirect($location){
    header("location:$location");
}


//=============  Start User Authentication  =============

//=============  Register  =============

function register(){
    $username=$_POST["username"];
    $email=$_POST["email"];
    $password=$_POST["password"];
    $cpassword=$_POST["cpassword"];

    $secure_password=password_hash($password,PASSWORD_DEFAULT);

    if ($password !== $cpassword){
        return alert("Password doesn't match !!!",'danger');
    }else{
        $sql="INSERT INTO users (name,email,password) VALUES ('$username','$email','$secure_password')";
        if (runQuery($sql)){
            return alert('Password are created successfully','success');
        }
    }
}


//=============  Login  =============

function login(){
    $email=$_POST["email"];
    $password=$_POST["password"];

    $sql="SELECT * FROM users WHERE email='$email'";
    $query=mysqli_query(conn(),$sql);
    $row=mysqli_fetch_assoc($query);

    if (!$row){
        //=============  Login or Email Fail  =============
        return alert("Email or Password doesn't match !!!",'danger');
    }else{

        //=============  Login Success  =============

        if (!password_verify($password,$row['password'])){

            //=============  Login Password Fail  =============
            return alert("Email or Password doesn't match !!!",'danger');
        }else{

            //=============  Login Password Success  =============
            session_start();
            $_SESSION['user']=$row;
            redirect("dashboard.php");
            //return alert("User is correct",'success');

        }
    }
}


//=============  End User Authentication  =============





?>

